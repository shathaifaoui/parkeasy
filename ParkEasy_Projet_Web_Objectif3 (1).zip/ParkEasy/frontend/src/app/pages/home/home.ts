import { Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { map } from 'rxjs';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { SearchState } from '../../core/search-state.service';
import { Icon } from '../../shared/icon';
import { SearchForm } from '../../shared/search-form';
import { Loader, ParkingTile } from '../../shared/ui';

@Component({
  selector: 'app-home',
  imports: [RouterLink, Icon, SearchForm, ParkingTile, Loader],
  templateUrl: './home.html',
  styleUrl: './home.scss',
})
export class HomePage {
  private api = inject(ApiService);
  protected auth = inject(AuthService);
  protected state = inject(SearchState);

  protected stats = toSignal(this.api.stats());
  // Parkings populaires : les mieux notés de Tunis, disponibilités sur le créneau en cours
  protected popular = toSignal(this.api.search({ city: 'Tunis', sort: 'rating', limit: 3, ...this.state.slot() }).pipe(map((r) => r.results)));

  protected steps = [
    { icon: 'search', title: 'Rechercher', text: 'Zone, date et durée' },
    { icon: 'grid', title: 'Comparer', text: 'Tarifs, services, places' },
    { icon: 'check', title: 'Réserver', text: 'Place et créneau garantis' },
    { icon: 'list', title: 'Suivre', text: 'Depuis votre espace' },
  ];
}
