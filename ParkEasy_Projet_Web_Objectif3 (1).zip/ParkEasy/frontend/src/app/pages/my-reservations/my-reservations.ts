import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { errorMessage } from '../../core/auth.interceptor';
import { Reservation } from '../../core/models';
import { ToastService } from '../../core/toast.service';
import { Icon } from '../../shared/icon';
import { DateFrPipe, DurationPipe, Empty, HourPipe, Loader, Modal, Stars, StatusBadge, TndPipe } from '../../shared/ui';

type Tab = 'upcoming' | 'past' | 'cancelled';

@Component({
  selector: 'app-my-reservations',
  imports: [FormsModule, RouterLink, Icon, StatusBadge, TndPipe, DateFrPipe, HourPipe, DurationPipe, Loader, Empty, Modal, Stars],
  templateUrl: './my-reservations.html',
  styleUrl: './my-reservations.scss',
})
export class MyReservationsPage {
  private api = inject(ApiService);
  private toast = inject(ToastService);

  protected tab = signal<Tab>('upcoming');
  protected list = signal<Reservation[] | null>(null);
  protected counts = signal<Record<string, number>>({});
  protected reviewing = signal<Reservation | null>(null);
  protected cancelling = signal<Reservation | null>(null);
  protected rating = signal(5);
  protected comment = '';
  protected tabs: { v: Tab; label: string }[] = [
    { v: 'upcoming', label: 'À venir' },
    { v: 'past', label: 'Passées' },
    { v: 'cancelled', label: 'Annulées' },
  ];

  constructor() {
    this.load();
  }

  select(t: Tab) {
    this.tab.set(t);
    this.load();
  }

  load() {
    this.list.set(null);
    this.api.myReservations(this.tab()).subscribe((r) => {
      this.list.set(r.results);
      this.counts.set(r.counts);
    });
  }

  canCancel(r: Reservation) {
    return ['pending', 'confirmed'].includes(r.status) && new Date(r.start_at).getTime() > Date.now();
  }

  isOngoing(r: Reservation) {
    const now = Date.now();
    return r.status === 'confirmed' && new Date(r.start_at).getTime() <= now && new Date(r.end_at).getTime() > now;
  }

  directions(r: Reservation) {
    return `https://www.google.com/maps/dir/?api=1&destination=${r.latitude},${r.longitude}`;
  }

  confirmCancel() {
    const r = this.cancelling();
    if (!r) return;
    this.api.cancel(r.id).subscribe({
      next: (res) => {
        this.toast.success(res.message);
        this.cancelling.set(null);
        this.load();
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }

  openReview(r: Reservation) {
    this.rating.set(5);
    this.comment = '';
    this.reviewing.set(r);
  }

  sendReview() {
    const r = this.reviewing();
    if (!r) return;
    this.api.review(r.id, { rating: this.rating(), comment: this.comment }).subscribe({
      next: (res) => {
        this.toast.success(res.message);
        this.reviewing.set(null);
        this.load();
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }
}
