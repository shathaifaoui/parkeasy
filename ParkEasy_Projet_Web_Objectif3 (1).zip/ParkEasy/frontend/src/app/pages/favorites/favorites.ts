import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { ParkingCard } from '../../core/models';
import { SearchState } from '../../core/search-state.service';
import { ToastService } from '../../core/toast.service';
import { Icon } from '../../shared/icon';
import { DateFrPipe, Empty, Loader, ParkingTile } from '../../shared/ui';

@Component({
  selector: 'app-favorites',
  imports: [RouterLink, Icon, ParkingTile, Loader, Empty, DateFrPipe],
  template: `
    <div class="page">
      <div class="page-head">
        <div><h1>Mes parkings favoris</h1><p>Retrouvez en un clic les parkings que vous utilisez souvent.</p></div>
      </div>
      @if (list(); as items) {
        <div class="grid">
          @for (p of items; track p.id) {
            <div class="fav">
              <app-parking-tile [parking]="p" [query]="state.toQuery()" />
              <div class="row-between bar">
                <span class="muted small">Ajouté le {{ p.added_at | dateFr: 'short' }}</span>
                <button class="btn btn-sm btn-ghost remove" (click)="remove(p)"><app-icon name="heart" [size]="15" [filled]="true" /> Retirer</button>
              </div>
            </div>
          } @empty {
            <div class="card full"><app-empty icon="heart" text="Vous n'avez pas encore de favori. Ajoutez-en depuis la fiche d'un parking.">
              <a routerLink="/parkings" class="btn btn-sm btn-primary">Rechercher un parking</a></app-empty></div>
          }
        </div>
      } @else { <app-loader /> }
    </div>`,
  styles: `.bar { padding: .4rem .2rem 0; } .remove { color: var(--red); } .full { grid-column: 1 / -1; }`,
})
export class FavoritesPage {
  private api = inject(ApiService);
  private toast = inject(ToastService);
  protected state = inject(SearchState);
  protected list = signal<ParkingCard[] | null>(null);

  constructor() {
    this.api.favorites().subscribe((l) => this.list.set(l));
  }

  remove(p: ParkingCard) {
    this.api.setFavorite(p.id, false).subscribe(() => {
      this.list.update((l) => (l ?? []).filter((x) => x.id !== p.id));
      this.toast.info(`${p.name} retiré de vos favoris`);
    });
  }
}
