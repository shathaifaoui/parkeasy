import { Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { errorMessage } from '../../core/auth.interceptor';
import { AuthService } from '../../core/auth.service';
import { ParkingCard } from '../../core/models';
import { SearchState } from '../../core/search-state.service';
import { ToastService } from '../../core/toast.service';
import { Icon, amenityIcon } from '../../shared/icon';
import { ParkingMap } from '../../shared/parking-map';
import { SearchForm } from '../../shared/search-form';
import { DateFrPipe, Empty, Loader, ParkingRow } from '../../shared/ui';

@Component({
  selector: 'app-search',
  imports: [FormsModule, Icon, SearchForm, ParkingMap, ParkingRow, Loader, Empty, DateFrPipe],
  templateUrl: './search.html',
  styleUrl: './search.scss',
})
export class SearchPage {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private toast = inject(ToastService);
  protected auth = inject(AuthService);
  protected state = inject(SearchState);

  protected zones = toSignal(this.api.zones$, { initialValue: [] });
  protected amenities = toSignal(this.api.amenities$, { initialValue: [] });
  protected amenityIcon = amenityIcon;

  // Filtres (appliqués à la demande)
  protected maxPrice = signal(6);
  protected onlyAvailable = signal(true);
  protected selectedAmenities = signal<number[]>([]);
  protected sort = signal<'price' | 'rating' | 'places' | 'distance'>('price');
  protected q = signal('');

  protected results = signal<ParkingCard[] | null>(null);
  protected loading = signal(false);
  protected editing = signal(false);
  protected showFilters = signal(false);
  protected hovered = signal<number | null>(null);
  protected position = signal<[number, number] | null>(null);
  protected favorites = signal<Set<number>>(new Set());

  protected zoneLabel = computed(() => {
    const z = this.zones().find((x) => x.id === this.state.zone());
    return z ? `${z.city}, ${z.name}` : this.q() ? `« ${this.q()} »` : 'Toutes les zones';
  });
  protected durationLabel = computed(() => {
    const m = this.state.minutes();
    return `${Math.floor(m / 60)} h${m % 60 ? ' ' + (m % 60) : ''}`;
  });
  protected navQuery = computed(() => this.state.toQuery());
  protected activeFilters = computed(() => (this.maxPrice() < 6 ? 1 : 0) + this.selectedAmenities().length + (this.onlyAvailable() ? 1 : 0));

  constructor() {
    this.route.queryParamMap.subscribe((qp) => {
      this.state.fromQuery(qp);
      this.q.set(qp.get('q') ?? '');
      this.load();
    });
    if (this.auth.isDriver()) this.api.favorites().subscribe((f) => this.favorites.set(new Set(f.map((p) => p.id))));
  }

  load() {
    if (!this.state.valid()) return;
    this.loading.set(true);
    const pos = this.position();
    this.api
      .search({
        ...this.state.slot(),
        zone: this.state.zone(),
        q: this.q() || null,
        maxPrice: this.maxPrice() < 6 ? this.maxPrice() : null,
        available: this.onlyAvailable() ? 1 : null,
        amenities: this.selectedAmenities().join(',') || null,
        sort: this.sort(),
        lat: pos?.[0],
        lng: pos?.[1],
      })
      .subscribe({
        next: (r) => {
          this.results.set(r.results);
          this.loading.set(false);
        },
        error: (e) => {
          this.toast.error(errorMessage(e));
          this.loading.set(false);
        },
      });
  }

  toggleAmenity(id: number, on: boolean) {
    this.selectedAmenities.update((l) => (on ? [...l, id] : l.filter((x) => x !== id)));
  }

  apply() {
    this.showFilters.set(false);
    this.load();
  }

  clearFilters() {
    this.maxPrice.set(6);
    this.onlyAvailable.set(false);
    this.selectedAmenities.set([]);
    this.load();
  }

  clearQuery() {
    this.router.navigate([], { queryParams: { q: null }, queryParamsHandling: 'merge' });
  }

  onSearched() {
    this.editing.set(false);
    this.router.navigate([], { queryParams: { ...this.state.toQuery(), q: null } });
  }

  setSort(v: 'price' | 'rating' | 'places' | 'distance') {
    if (v === 'distance' && !this.position()) return this.locate();
    this.sort.set(v);
    this.load();
  }

  /** « Autour de moi » : géolocalisation du navigateur, tri par distance */
  locate() {
    if (!navigator.geolocation) return this.toast.error("La géolocalisation n'est pas disponible sur ce navigateur.");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        this.position.set([p.coords.latitude, p.coords.longitude]);
        this.sort.set('distance');
        this.load();
      },
      () => this.toast.error('Position refusée : autorisez la localisation pour trier par distance.'),
      { timeout: 8000 }
    );
  }

  scrollTo(id: number) {
    this.hovered.set(id);
    document.getElementById(`res-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  toggleFavorite(id: number) {
    const on = !this.favorites().has(id);
    this.api.setFavorite(id, on).subscribe(() => {
      this.favorites.update((s) => {
        const n = new Set(s);
        if (on) n.add(id);
        else n.delete(id);
        return n;
      });
      this.toast.success(on ? 'Ajouté à vos favoris' : 'Retiré de vos favoris');
    });
  }
}
