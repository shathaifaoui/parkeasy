import { Component, computed, effect, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Subscription, filter, interval, startWith, switchMap } from 'rxjs';
import { ApiService } from './core/api.service';
import { AuthService } from './core/auth.service';
import { Notification, ROLE_LABEL } from './core/models';
import { ToastService } from './core/toast.service';
import { Icon } from './shared/icon';
import { DateFrPipe } from './shared/ui';

interface MenuItem { label: string; icon: string; link: string; exact?: boolean }

const MENUS: Record<string, MenuItem[]> = {
  driver: [
    { label: 'Accueil', icon: 'home', link: '/', exact: true },
    { label: 'Rechercher', icon: 'search', link: '/parkings' },
    { label: 'Mes réservations', icon: 'list', link: '/mes-reservations' },
    { label: 'Favoris', icon: 'heart', link: '/favoris' },
    { label: 'Profil', icon: 'user', link: '/profil' },
  ],
  manager: [
    { label: 'Tableau de bord', icon: 'home', link: '/gestion', exact: true },
    { label: 'Parkings & places', icon: 'building', link: '/gestion/parkings' },
    { label: 'Réservations', icon: 'list', link: '/gestion/reservations' },
    { label: 'Profil', icon: 'settings', link: '/profil' },
  ],
  admin: [
    { label: 'Supervision', icon: 'grid', link: '/admin', exact: true },
    { label: 'Parkings publiés', icon: 'search', link: '/parkings' },
    { label: 'Profil', icon: 'settings', link: '/profil' },
  ],
};

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, FormsModule, Icon, DateFrPipe],
  templateUrl: './app.html',
  styleUrl: './app.scss',
  host: { '(document:click)': 'closeMenus($event)' },
})
export class App {
  protected auth = inject(AuthService);
  protected toast = inject(ToastService);
  private api = inject(ApiService);
  private router = inject(Router);

  protected menu = computed(() => MENUS[this.auth.role() ?? 'driver']);
  protected roleLabel = computed(() => (this.auth.role() ? ROLE_LABEL[this.auth.role()!] : ''));
  protected initials = computed(() => {
    const u = this.auth.user();
    return u ? (u.first_name[0] + u.last_name[0]).toUpperCase() : '';
  });
  protected searchPlaceholder = computed(() =>
    this.auth.isManager() ? 'Rechercher une réservation, un client, une place…' : 'Rechercher un parking, une adresse ou une ville…');

  protected drawerOpen = signal(false);
  protected bellOpen = signal(false);
  protected userOpen = signal(false);
  protected publicMenuOpen = signal(false);
  protected query = '';
  protected notifs = signal<{ count: number; items: Notification[] }>({ count: 0, items: [] });
  protected year = new Date().getFullYear();

  constructor() {
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd), takeUntilDestroyed()).subscribe(() => {
      this.drawerOpen.set(false);
      this.bellOpen.set(false);
      this.userOpen.set(false);
      this.publicMenuOpen.set(false);
    });

    // Notifications : interrogées toutes les 60 secondes pour un utilisateur connecté
    let sub: Subscription | undefined;
    effect(() => {
      sub?.unsubscribe();
      this.notifs.set({ count: 0, items: [] });
      if (!this.auth.isLoggedIn()) return;
      sub = interval(60_000).pipe(startWith(0), switchMap(() => this.api.notifications())).subscribe((n) => this.notifs.set(n));
    });
  }

  search() {
    const q = this.query.trim();
    if (this.auth.isManager()) this.router.navigate(['/gestion/reservations'], { queryParams: { q } });
    else this.router.navigate(['/parkings'], { queryParams: { q: q || null } });
    this.query = '';
  }

  closeMenus(e: Event) {
    const t = e.target as HTMLElement;
    if (!t.closest('.bell-wrap')) this.bellOpen.set(false);
    if (!t.closest('.user-wrap')) this.userOpen.set(false);
  }

  logout() {
    this.auth.logout();
    this.toast.info('Vous êtes déconnecté.');
  }
}
