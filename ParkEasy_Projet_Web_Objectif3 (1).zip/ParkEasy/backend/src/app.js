const express = require('express');
const cors = require('cors');

function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '100kb' }));

  app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'ParkEasy API' }));
  app.use('/api/auth', require('./routes/auth').router);
  app.use('/api', require('./routes/parkings').router);
  app.use('/api', require('./routes/driver'));
  app.use('/api', require('./routes/notifications'));
  app.use('/api/manager', require('./routes/manager'));
  app.use('/api/admin', require('./routes/admin'));

  app.use('/api', (_req, res) => res.status(404).json({ message: 'Route API introuvable' }));

  // Gestion centralisée des erreurs (dont les erreurs PostgreSQL)
  app.use((err, _req, res, _next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'JSON invalide' });
    if (err.code === '23P01') return res.status(409).json({ message: 'Cette place est déjà réservée sur ce créneau' });
    if (err.code === '23505') return res.status(409).json({ message: 'Cet élément existe déjà' });
    if (['22P02', '23514', '23502', '22007', '22008', '23503'].includes(err.code)) return res.status(400).json({ message: 'Données invalides' });
    if (err.status && err.status < 500) return res.status(err.status).json({ message: err.message });
    console.error(err);
    res.status(500).json({ message: 'Erreur interne du serveur' });
  });
  return app;
}

module.exports = { createApp };
