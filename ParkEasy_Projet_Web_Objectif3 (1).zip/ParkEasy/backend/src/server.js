// Chargement de la configuration (backend/.env) — fonctionnalité native de Node.js ≥ 20.12
try {
  process.loadEnvFile(require('path').join(__dirname, '..', '.env'));
} catch {
  /* pas de fichier .env : valeurs par défaut (postgres / postgres sur localhost:5432) */
}

const { initDb, config } = require('./db');
const { createApp } = require('./app');

const PORT = process.env.PORT || 3000;
const reset = process.argv.includes('--reset');

initDb({ reset })
  .then(() => {
    createApp().listen(PORT, () => {
      console.log(`\n  🅿️  ParkEasy API démarrée sur http://localhost:${PORT}/api`);
      console.log(`     PostgreSQL : ${config.user}@${config.host}:${config.port}/${config.database}\n`);
    });
  })
  .catch(() => process.exit(1));
